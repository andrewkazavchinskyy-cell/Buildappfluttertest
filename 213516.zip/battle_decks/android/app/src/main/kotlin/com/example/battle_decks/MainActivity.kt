package com.example.battle_decks

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
