import 'package:shared_preferences/shared_preferences.dart';

class PreferencesService {
  final SharedPreferences _preferences;

  PreferencesService(this._preferences);

  static const _coinsKey = "COINS_KEY";
  static const _musicKey = "MUSIC_KEY";
  static const _tutorialKey = "TUTORIAL_KEY";
  static const _notiKey = "NOTI_KEY";

  Future<void> setCoins(int coins) async {
    await _preferences.setInt(_coinsKey, coins);
  }

  int getCoins() {
    return _preferences.getInt(_coinsKey) ?? 100;
  }

  Future<void> setMusic(bool music) async {
    await _preferences.setBool(_musicKey, music);
  }

  bool getMusic() {
    return _preferences.getBool(_musicKey) ?? true;
  }

  Future<void> setTutorial() async {
    await _preferences.setBool(_tutorialKey, false);
  }

  bool getTutorial() {
    return _preferences.getBool(_tutorialKey) ?? true;
  }

  Future<void> setNoti(bool noti) async {
    await _preferences.setBool(_notiKey, noti);
  }

  bool getNoti() {
    return _preferences.getBool(_notiKey) ?? true;
  }
}
