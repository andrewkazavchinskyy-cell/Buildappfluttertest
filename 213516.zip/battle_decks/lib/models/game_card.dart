enum CardSuit { clubs, diamonds, spades, hearts }

class GameCard {
  final CardSuit cardSuit;
  final int rank;
  final String asset;

  GameCard({required this.cardSuit, required this.rank, required this.asset});
}
