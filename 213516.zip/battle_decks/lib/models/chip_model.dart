class ChipModel {
  final int id;
  final int value;
  final String asset;
  final String selectedAsset;

  ChipModel({
    required this.id,
    required this.value,
    required this.asset,
    required this.selectedAsset,
  });

  factory ChipModel.empty() =>
      ChipModel(id: -1, value: 0, asset: '', selectedAsset: '');
}
