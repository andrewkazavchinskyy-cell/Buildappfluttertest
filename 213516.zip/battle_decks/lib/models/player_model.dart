import 'package:battle_decks/models/models.dart';

class PlayerModel {
  final int id;
  final String name;
  int bank;
  final List<ChipModel> chips;
  final List<ChipModel> tieChips;
  GameCard? gameCard;

  PlayerModel({
    required this.id,
    required this.name,
    required this.bank,
    required this.chips,
    required this.tieChips,
  });

  int get chipsSum =>
      chips.isNotEmpty ? chips.fold(0, (sum, chip) => sum + chip.value) : 0;

  int get tieChipsSum => tieChips.isNotEmpty
      ? tieChips.fold(0, (sum, chip) => sum + chip.value)
      : 0;
}
