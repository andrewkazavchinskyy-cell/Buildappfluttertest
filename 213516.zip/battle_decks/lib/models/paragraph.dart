class Paragraph {
  final String title;
  final String body;

  Paragraph({required this.title, required this.body});
}
