import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

import '../utils/utils.dart';

class CustomNotification {
  static void show(
    BuildContext context, {
    Duration duration = const Duration(seconds: 1),
    required String message,
  }) {
    final overlay = Overlay.of(context);
    late OverlayEntry overlayEntry;

    overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        top: 14,
        left: 0,
        right: 0,
        child: Center(
          child: SafeArea(
            child: _NotificationWidget(
              message: message,
              duration: duration,
              onDismissed: () {
                overlayEntry.remove();
              },
            ),
          ),
        ),
      ),
    );

    overlay.insert(overlayEntry);
  }
}

class _NotificationWidget extends StatefulWidget {
  final String message;
  final VoidCallback onDismissed;
  final Duration duration;

  const _NotificationWidget({
    Key? key,
    required this.message,
    required this.onDismissed,
    required this.duration,
  }) : super(key: key);

  @override
  State<_NotificationWidget> createState() => _NotificationWidgetState();
}

class _NotificationWidgetState extends State<_NotificationWidget>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<Offset> _offsetAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );

    _offsetAnimation = Tween<Offset>(
      begin: const Offset(0, -1),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

    _controller.forward();

    Future.delayed(widget.duration, _dismiss);
  }

  void _dismiss() {
    _controller.reverse().then((_) {
      widget.onDismissed();
    });
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      position: _offsetAnimation,
      child: Material(
        type: MaterialType.transparency,
        child: Container(
          constraints: BoxConstraints(minWidth: 247.w),
          decoration: BoxDecoration(
            color: AppColors.layersLayer1,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(width: 3.sp, color: AppColors.systemError),
          ),
          padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
          child: Row(
            children: [
              Text(widget.message, style: AppTextStyles.headerSSecondary),
              Gap(14.w),
              GestureDetector(
                onTap: _dismiss,
                child: Image.asset(
                  'assets/png/close.png',
                  width: 24.r,
                  height: 24.r,
                  fit: BoxFit.fill,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
