import 'package:battle_decks/models/models.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

import '../utils/utils.dart';

class CoinsWidget2 extends StatelessWidget {
  const CoinsWidget2({super.key, required this.playerModel});

  final PlayerModel playerModel;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 193.w,
      height: 44.h,
      decoration: BoxDecoration(
        color: AppColors.layersLayer1,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(width: 3.sp, color: AppColors.strokeStroke1),
      ),
      child: Row(
        children: [
          Expanded(
            child: Center(
              child: Text(
                playerModel.name,
                style: AppTextStyles.headerMSecondary,
              ),
            ),
          ),
          Container(
            width: 91.w,
            height: 44.h,
            decoration: BoxDecoration(
              color: AppColors.layersLayer2,
              border: Border.all(
                width: 3.sp,
                color: AppColors.strokeStroke1,
                strokeAlign: 1,
              ),
              borderRadius: BorderRadius.horizontal(right: Radius.circular(12)),
            ),
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/png/coin.png',
                  width: 24.r,
                  height: 24.r,
                  fit: BoxFit.fill,
                ),
                Gap(5.w),
                Flexible(
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 4.h),
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        "${playerModel.bank}",
                        style: AppTextStyles.headerMSecondary,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
