import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

import '../utils/utils.dart';

class CustomNumberInput extends StatefulWidget {
  const CustomNumberInput({
    super.key,
    required this.number,
    required this.onChanged,
  });

  final int number;
  final void Function(int value) onChanged;

  @override
  State<CustomNumberInput> createState() => _CustomNumberInputState();
}

class _CustomNumberInputState extends State<CustomNumberInput> {
  late final controller = TextEditingController(
    text: NumberFormat("#,###").format(widget.number).replaceAll(',', ' '),
  );

  bool isError = false;

  void _validate(String? newValue) {
    final text = newValue?.replaceAll(RegExp(r'\s+'), '');
    if (text == null || text.isEmpty) {
      setState(() => isError = false);
      return;
    }

    final value = int.tryParse(text);
    if (value == null) return;

    setState(() => isError = value < 100 || value > 100000);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        if (isError)
          Transform.translate(
            offset: Offset(0, 44.h),
            child: Text(
              "Limit 100-100 000",
              style: AppTextStyles.caption.copyWith(
                color: AppColors.systemError,
              ),
            ),
          ),
        SizedBox(
          width: 156.w,
          height: 44.h,
          child: TextField(
            controller: controller,
            onChanged: _validate,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              ThousandsFormatter(),
            ],
            style: AppTextStyles.headerSSecondary.copyWith(
              color: AppColors.textSecondary,
            ),
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.only(
                left: 12.w,
                right: 12.w,
                bottom: 3.h,
              ),
              filled: true,
              fillColor: AppColors.layersLayer1,
              hintText: '',
              hintStyle: TextStyle(color: AppColors.textSecondary),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: AppColors.layersLayer2,
                  width: 3.sp,
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isError
                      ? AppColors.systemError
                      : AppColors.strokeStroke1,
                  width: 3.sp,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(
                  color: isError
                      ? AppColors.systemError
                      : AppColors.strokeStroke2,
                  width: 3.sp,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class ThousandsFormatter extends TextInputFormatter {
  final NumberFormat _formatter = NumberFormat('#,###', 'ru_RU');

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    String digitsOnly = newValue.text.replaceAll(RegExp(r'\D'), '');
    if (digitsOnly.isEmpty) return newValue.copyWith(text: '');

    String formatted = _formatter
        .format(int.parse(digitsOnly))
        .replaceAll(',', ' ');

    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }
}
