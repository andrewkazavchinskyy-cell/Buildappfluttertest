import 'package:battle_decks/providers/providers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../utils/utils.dart';

class CoinsWidget extends StatelessWidget {
  const CoinsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 103.w,
      height: 44.h,
      child: Row(
        children: [
          Container(
            width: 44.w,
            height: 44.h,
            decoration: BoxDecoration(
              color: AppColors.layersLayer2,
              border: Border(
                top: BorderSide(width: 3.sp, color: AppColors.strokeStroke1),
                left: BorderSide(width: 3.sp, color: AppColors.strokeStroke1),
                bottom: BorderSide(width: 3.sp, color: AppColors.strokeStroke1),
              ),
              borderRadius: BorderRadius.horizontal(left: Radius.circular(12)),
            ),
            alignment: Alignment.center,
            child: Image.asset(
              'assets/png/coin.png',
              width: 24.r,
              height: 24.r,
              fit: BoxFit.fill,
            ),
          ),
          Consumer<ConfigProvider>(
            builder: (BuildContext context, value, Widget? child) {
              return Container(
                width: 59.w,
                height: 44.h,
                decoration: BoxDecoration(
                  color: AppColors.layersLayer1,
                  border: Border(
                    top: BorderSide(
                      width: 3.sp,
                      color: AppColors.strokeStroke1,
                    ),
                    right: BorderSide(
                      width: 3.sp,
                      color: AppColors.strokeStroke1,
                    ),
                    bottom: BorderSide(
                      width: 3.sp,
                      color: AppColors.strokeStroke1,
                    ),
                  ),
                  borderRadius: BorderRadius.horizontal(
                    right: Radius.circular(12),
                  ),
                ),
                alignment: Alignment.center,
                padding: EdgeInsets.only(bottom: 4.r),
                child: Text(
                  "${value.coins}",
                  style: AppTextStyles.headerMSecondary,
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
