import 'package:flutter/cupertino.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

import '../../utils/utils.dart';

class CustomSwitch extends StatelessWidget {
  const CustomSwitch({super.key, required this.onToggle, this.value = true});

  final bool value;
  final void Function(bool) onToggle;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 197.r,
      height: 53.r,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/png/button1.png'),
          fit: BoxFit.fill,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "Notifications",
            style: AppTextStyles.headerMSecondary.copyWith(
              color: AppColors.textPrimary,
            ),
          ),
          Gap(2.w),
          CupertinoSwitch(value: value, onChanged: onToggle),
        ],
      ),
    );
  }
}
