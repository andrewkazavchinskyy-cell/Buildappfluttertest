import 'package:battle_decks/models/models.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';

import '../../utils/utils.dart';

class Button4 extends StatelessWidget {
  const Button4({
    super.key,
    required this.text,
    this.onTap,
    this.leftPadding,
    this.rightPadding,
    required this.chips,
    required this.sum,
  });

  final String text;
  final int sum;
  final List<ChipModel> chips;
  final double? leftPadding;
  final double? rightPadding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final number = NumberFormat(
      '#,###',
      'ru_RU',
    ).format(sum).replaceAll(',', ' ');
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.translucent,
      child: Container(
        width: 288.w,
        height: 59.h,
        decoration: BoxDecoration(
          color: AppColors.layersLayer4,
          backgroundBlendMode: BlendMode.multiply,
        ),
        padding: EdgeInsets.only(
          left: leftPadding ?? 32.w,
          right: rightPadding ?? 17.w,
        ),
        child: Row(
          children: [
            Text("$text $number", style: AppTextStyles.headerSPrimaryBold),
            Expanded(
              child: Stack(
                alignment: Alignment.center,
                children: List.generate(chips.length, (index) {
                  final chip = chips[index];

                  double maxChipsVisible = 15;
                  double size = 25.r;
                  double spacing = 4.w;

                  if (chips.length > maxChipsVisible) {
                    double factor = maxChipsVisible / chips.length;
                    size = 25.r * factor;
                    spacing = 4.w * factor;
                  }

                  final x = (chips.length - index) * spacing;

                  return Positioned(
                    right: x,
                    child: Image.asset(
                      chip.asset,
                      width: size,
                      height: size,
                      fit: BoxFit.fill,
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
