import 'package:battle_decks/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class Button3 extends StatelessWidget {
  const Button3({
    super.key,
    required this.text,
    required this.bgColor,
    required this.strokeColor,
    this.onTap,
    this.width,
    this.height,
    this.isEnabled = true,
  });

  final String text;
  final double? width;
  final double? height;
  final Color bgColor;
  final Color strokeColor;
  final bool isEnabled;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: width ?? 126.w,
        height: height ?? 48.h,
        decoration: BoxDecoration(
          color: isEnabled ? bgColor : AppColors.layersLayer1,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            width: 3.sp,
            color: isEnabled ? strokeColor : AppColors.layersLayer1,
          ),
        ),
        alignment: Alignment.center,
        child: Text(
          text,
          style: AppTextStyles.headerMBold.copyWith(
            color: isEnabled ? null : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}
