import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../utils/utils.dart';

class CustomIconButton extends StatelessWidget {
  const CustomIconButton({super.key, required this.icon, this.onTap});

  final String icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44.r,
        height: 44.r,
        decoration: BoxDecoration(
          color: AppColors.layersLayer2,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(width: 3.sp, color: AppColors.strokeStroke1),
        ),
        alignment: Alignment.center,
        child: Image.asset(icon, width: 24.r, height: 24.r, fit: BoxFit.fill),
      ),
    );
  }
}
