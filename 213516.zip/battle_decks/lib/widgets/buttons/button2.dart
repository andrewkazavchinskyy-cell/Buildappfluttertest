import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

import '../../utils/utils.dart';

class Button2 extends StatelessWidget {
  const Button2({
    super.key,
    required this.title,
    required this.icon,
    this.onTap,
  });

  final String title;
  final String icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 197.r,
        height: 53.r,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/png/button1.png'),
            fit: BoxFit.fill,
          ),
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(title, style: AppTextStyles.headerMSecondary),
            Gap(12.r),
            Image.asset(icon, width: 24.r, height: 24.r, fit: BoxFit.fill),
          ],
        ),
      ),
    );
  }
}
