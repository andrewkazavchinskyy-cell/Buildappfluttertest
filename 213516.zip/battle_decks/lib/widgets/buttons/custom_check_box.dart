import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../utils/utils.dart';

class CustomCheckBox extends StatelessWidget {
  const CustomCheckBox({super.key, this.isTapped = true, this.onTap});

  final bool isTapped;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44.r,
        height: 44.r,
        decoration: BoxDecoration(
          color: isTapped ? AppColors.layersLayer3 : AppColors.layersLayer1,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            width: 3.sp,
            color: isTapped ? AppColors.strokeStroke3 : AppColors.layersLayer2,
          ),
        ),
        alignment: Alignment.center,
        child: isTapped
            ? Image.asset(
                'assets/png/tick.png',
                width: 24.r,
                height: 24.r,
                fit: BoxFit.fill,
              )
            : SizedBox(),
      ),
    );
  }
}
