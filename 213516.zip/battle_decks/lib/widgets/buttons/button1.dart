import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../utils/utils.dart';

class Button1 extends StatelessWidget {
  const Button1({super.key, required this.title, this.onTap});

  final String title;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 197.r,
        height: 53.r,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/png/button1.png'),
            fit: BoxFit.fill,
          ),
        ),
        alignment: Alignment.center,
        child: Text(
          title,
          style: AppTextStyles.headerMSecondary.copyWith(
            color: AppColors.textPrimary,
          ),
        ),
      ),
    );
  }
}
