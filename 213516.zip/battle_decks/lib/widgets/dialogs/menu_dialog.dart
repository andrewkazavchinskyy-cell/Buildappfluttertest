import 'package:battle_decks/utils/utils.dart';
import 'package:battle_decks/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

class MenuDialog extends StatelessWidget {
  const MenuDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: SizedBox(
        width: 318.r,
        height: 311.h,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 265.w,
              height: 311.h,
              decoration: BoxDecoration(
                color: AppColors.layersLayer1,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(width: 8.sp, color: AppColors.layersLayer2),
              ),
              child: Column(
                children: [
                  Gap(96.h),
                  Button1(title: "Resume", onTap: Navigator.of(context).pop),
                  Gap(12.h),
                  Button1(
                    title: "How to Play",
                    onTap: () => showInfoDialog(context),
                  ),
                  Gap(12.h),
                  Button1(
                    title: "Exit",
                    onTap: () {
                      Navigator.of(context).pop();
                      showExitDialog(context);
                    },
                  ),
                ],
              ),
            ),
            Positioned(
              top: 0,
              child: Image.asset(
                'assets/png/pause_title.png',
                width: 319.r,
                height: 84.r,
                fit: BoxFit.fill,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void showInfoDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierColor: Colors.transparent,
      builder: (context) {
        return Center(child: const InfoDialog());
      },
    );
  }

  void showExitDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierColor: AppColors.backgroundSecondary.withValues(alpha: 0.7),
      builder: (context) {
        return Center(child: const ExitDialog());
      },
    );
  }
}
