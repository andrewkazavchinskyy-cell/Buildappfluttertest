import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';

import '../../utils/utils.dart';
import '../widgets.dart';

class ExitDialog extends StatelessWidget {
  const ExitDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Container(
        width: 301.w,
        height: 179.h,
        decoration: BoxDecoration(
          color: AppColors.layersLayer1,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(width: 8.sp, color: AppColors.layersLayer2),
        ),
        padding: EdgeInsets.symmetric(vertical: 20.h),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Are you sure you want to\nExit?",
              style: AppTextStyles.headerMSecondary,
              textAlign: TextAlign.center,
            ),
            SizedBox(
              width: 261.w,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Button3(
                    text: "Cancel",
                    bgColor: AppColors.layersLayer2,
                    strokeColor: AppColors.strokeStroke1,
                    onTap: Navigator.of(context).pop,
                  ),
                  Button3(
                    text: "Exit",
                    bgColor: AppColors.layersLayer3,
                    strokeColor: AppColors.strokeStroke3,
                    onTap: () {
                      Navigator.of(context).pop();
                      context.pop();
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
