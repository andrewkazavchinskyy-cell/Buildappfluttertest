import 'package:battle_decks/models/models.dart';
import 'package:battle_decks/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

import '../../utils/utils.dart';

class BattleDialog2 extends StatelessWidget {
  const BattleDialog2({
    super.key,
    this.onBattle,
    this.onSurrender,
    required this.players,
  });

  final List<PlayerModel> players;
  final VoidCallback? onBattle;
  final VoidCallback? onSurrender;

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: SizedBox(
        width: 318.r,
        height: 322.h,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 265.w,
              height: 322.h,
              decoration: BoxDecoration(
                color: AppColors.layersLayer1,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(width: 8.sp, color: AppColors.layersLayer2),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12.w),
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        children: List.generate(players.length, (index) {
                          final player = players[index];
                          final last = index == players.length - 1;

                          double baseFontSize = 24.r;
                          double fontSize =
                              (baseFontSize - (players.length - 2) * 1.5).clamp(
                                12.0,
                                baseFontSize,
                              );

                          final nameStyle = AppTextStyles.headerMSecondary
                              .copyWith(
                                fontSize: fontSize,
                                color: AppColors.strokeStroke2,
                              );

                          final textStyle = AppTextStyles.headerMSecondary
                              .copyWith(fontSize: fontSize);

                          if (last) {
                            return TextSpan(
                              children: [
                                TextSpan(text: player.name, style: nameStyle),
                                TextSpan(
                                  text: " it is Tie, will you battle?",
                                  style: textStyle,
                                ),
                              ],
                            );
                          }

                          return TextSpan(
                            children: [
                              TextSpan(text: player.name, style: nameStyle),
                              TextSpan(text: " and ", style: textStyle),
                            ],
                          );
                        }),
                      ),
                    ),
                  ),
                  Gap(23.h),
                  Button3(
                    text: "Battle",
                    width: 184.w,
                    bgColor: AppColors.layersLayer4,
                    strokeColor: AppColors.strokeStroke3,
                    onTap: () {
                      Navigator.pop(context);
                      onBattle?.call();
                    },
                  ),
                  Gap(11.h),
                  Button3(
                    text: "Surrender",
                    width: 184.w,
                    bgColor: AppColors.layersLayer2,
                    strokeColor: AppColors.strokeStroke1,
                    onTap: () {
                      Navigator.pop(context);
                      onSurrender?.call();
                    },
                  ),
                  Gap(20.h),
                ],
              ),
            ),
            Positioned(
              top: 0,
              child: Image.asset(
                'assets/png/battle_title.png',
                width: 319.r,
                height: 84.r,
                fit: BoxFit.fill,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
