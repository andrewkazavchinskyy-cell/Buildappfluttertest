import 'package:battle_decks/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

class ResultDialog extends StatelessWidget {
  const ResultDialog({super.key, required this.value});

  final int value;

  @override
  Widget build(BuildContext context) {
    final won = value > 0;
    return Material(
      type: MaterialType.transparency,
      child: GestureDetector(
        onTap: Navigator.of(context).pop,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 396.w,
              height: 121.h,
              decoration: BoxDecoration(
                color: AppColors.layersLayer1,
                border: Border(
                  top: BorderSide(
                    width: 8.sp,
                    color: won ? AppColors.systemSuccess : AppColors.systemError,
                  ),
                  bottom: BorderSide(
                    width: 8.sp,
                    color: won ? AppColors.systemSuccess : AppColors.systemError,
                  ),
                ),
              ),
              alignment: Alignment.center,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    won ? "Victory" : "Defeated",
                    style: AppTextStyles.headerXLBold,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "$value",
                        style: AppTextStyles.headerLBold.copyWith(
                          color: won ? null : AppColors.systemError,
                        ),
                      ),
                      Gap(4.w),
                      Image.asset(
                        'assets/png/coin.png',
                        width: 24.r,
                        height: 24.r,
                        fit: BoxFit.fill,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Gap(22.h),
            Text(
              "Tap to close",
              style: AppTextStyles.headerSSecondary.copyWith(
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
