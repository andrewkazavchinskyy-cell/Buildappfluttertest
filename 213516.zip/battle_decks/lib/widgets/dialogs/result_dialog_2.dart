import 'package:battle_decks/models/models.dart';
import 'package:battle_decks/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';

class ResultDialog2 extends StatelessWidget {
  const ResultDialog2({super.key, required this.playerModel});

  final PlayerModel playerModel;

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: GestureDetector(
        onTap: Navigator.of(context).pop,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 396.w,
              height: 121.h,
              decoration: BoxDecoration(
                color: AppColors.layersLayer1,
                border: Border(
                  top: BorderSide(width: 8.sp, color: AppColors.systemSuccess),
                  bottom: BorderSide(
                    width: 8.sp,
                    color: AppColors.systemSuccess,
                  ),
                ),
              ),
              alignment: Alignment.center,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "${playerModel.name} Wins",
                    style: AppTextStyles.headerXLBold,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "${playerModel.chipsSum}",
                        style: AppTextStyles.headerLBold,
                      ),
                      Gap(4.w),
                      Image.asset(
                        'assets/png/coin.png',
                        width: 24.r,
                        height: 24.r,
                        fit: BoxFit.fill,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Gap(22.h),
            Text(
              "Tap to close",
              style: AppTextStyles.headerSSecondary.copyWith(
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
