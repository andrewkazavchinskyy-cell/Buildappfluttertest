import 'package:battle_decks/main.dart';
import 'package:battle_decks/providers/providers.dart';
import 'package:battle_decks/utils/utils.dart';
import 'package:battle_decks/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

class SettingsDialog extends StatelessWidget {
  const SettingsDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ConfigProvider>(
      builder: (BuildContext context, value, Widget? child) {
        return Material(
          type: MaterialType.transparency,
          child: SizedBox(
            width: 318.r,
            height: 504.r,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned(
                  top: 7.r,
                  child: Container(
                    width: 265.r,
                    height: 497.r,
                    decoration: BoxDecoration(
                      color: AppColors.layersLayer1,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        width: 8.sp,
                        color: AppColors.layersLayer2,
                      ),
                    ),
                    child: Column(
                      children: [
                        Gap(96.r),
                        CustomSwitch(
                          onToggle: value.toggleNoti,
                          value: value.noti,
                        ),
                        Gap(12.r),
                        Button2(
                          title: "Music",
                          icon: value.music
                              ? "assets/png/music_on.png"
                              : "assets/png/music_off.png",
                          onTap: value.toggleMusic,
                        ),
                        Gap(12.r),
                        Button1(title: "Rate Us", onTap: rateUs),
                        Gap(12.r),
                        Button1(
                          title: "Share App",
                          onTap: () {
                            SharePlus.instance.share(
                              ShareParams(
                                title:
                                    'Download our game here: https://apps.apple.com/us/app/chiumbi-vicitori-challenge/id6753083300',
                                subject: 'Chiumbi Vicitori Challenge',
                                uri: Uri.parse(
                                  "https://apps.apple.com/us/app/chiumbi-vicitori-challenge/id6753083300",
                                ),
                              ),
                            );
                          },
                        ),
                        Gap(12.r),
                        Button1(
                          title: "Privacy Policy",
                          onTap: () => launchUri(
                            "https://docs.google.com/document/d/1TWWrhsEECjv1RtfXutgsOnjnD7qBBrTErc2Pdgk1bXA/edit?tab=t.0",
                          ),
                        ),
                        Gap(12.r),
                        CustomIconButton(
                          icon: "assets/png/close.png",
                          onTap: Navigator.of(context).pop,
                        ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  top: 0,
                  child: Image.asset(
                    'assets/png/settings_title.png',
                    width: 318.r,
                    height: 84.r,
                    fit: BoxFit.fill,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
