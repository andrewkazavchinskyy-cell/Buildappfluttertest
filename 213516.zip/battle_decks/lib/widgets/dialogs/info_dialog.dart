import 'package:battle_decks/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../widgets.dart';

class InfoDialog extends StatelessWidget {
  const InfoDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Container(
        width: 361.w,
        height: 622.h,
        decoration: BoxDecoration(
          color: AppColors.layersLayer1,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(width: 8.sp, color: AppColors.layersLayer2),
        ),
        padding: EdgeInsets.only(top: 32.h, bottom: 24.h),
        child: Column(
          children: [
            Row(
              children: [
                Image.asset(
                  'assets/png/how_to_play_title.png',
                  width: 236.r,
                  height: 56.r,
                  fit: BoxFit.fill,
                ),
                Spacer(),
                CustomIconButton(
                  icon: "assets/png/close.png",
                  onTap: () => Navigator.of(context).pop(),
                ),
                SizedBox(width: 16.r),
              ],
            ),
            SizedBox(height: 20.h),
            Expanded(
              child: SizedBox(
                width: 317.w,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: List.generate(gameInfo.length, (index) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          gameInfo[index].title,
                          style: AppTextStyles.headerMSecondary,
                        ),
                        Text(
                          gameInfo[index].body,
                          style: AppTextStyles.bodyPrimary,
                        ),
                      ],
                    );
                  }),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
