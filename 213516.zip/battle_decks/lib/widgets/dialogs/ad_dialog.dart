import 'package:battle_decks/providers/providers.dart';
import 'package:battle_decks/utils/utils.dart';
import 'package:battle_decks/widgets/buttons/button3.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';

class AdDialog extends StatefulWidget {
  const AdDialog({super.key});

  @override
  State<AdDialog> createState() => _AdDialogState();
}

class _AdDialogState extends State<AdDialog> {
  RewardedAd? _rewardedAd;

  @override
  void initState() {
    super.initState();
    _loadRewardedAd();
  }

  void _loadRewardedAd() {
    RewardedAd.load(
      adUnitId: 'ca-app-pub-4223251915375466/1725612498',
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          debugPrint('RewardedAd loaded');
        },
        onAdFailedToLoad: (error) {
          debugPrint('RewardedAd failed to load: $error');
        },
      ),
    );
  }

  void _showRewardedAd(VoidCallback onReward) {
    if (_rewardedAd == null) return;

    _rewardedAd!.show(
      onUserEarnedReward: (ad, reward) {
        debugPrint('User earned reward: ${reward.amount} ${reward.type}');
        onReward();
      },
    );

    _rewardedAd = null;
    _loadRewardedAd();
  }

  @override
  void dispose() {
    _rewardedAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: Container(
        width: 301.w,
        height: 179.h,
        decoration: BoxDecoration(
          color: AppColors.layersLayer1,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(width: 8.sp, color: AppColors.layersLayer2),
        ),
        padding: EdgeInsets.symmetric(vertical: 20.h),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "You don’t have coins, watch\nAd to gain 200!",
              style: AppTextStyles.headerMSecondary,
              textAlign: TextAlign.center,
            ),
            SizedBox(
              width: 261.w,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Button3(
                    text: "Cancel",
                    bgColor: AppColors.layersLayer2,
                    strokeColor: AppColors.strokeStroke1,
                    onTap: Navigator.of(context).pop,
                  ),
                  Button3(
                    text: "Watch",
                    bgColor: AppColors.layersLayer3,
                    strokeColor: AppColors.strokeStroke3,
                    onTap: () {
                      _showRewardedAd(
                        () {
                          context.read<ConfigProvider>().addCoins(200);
                          Navigator.of(context).pop();
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
