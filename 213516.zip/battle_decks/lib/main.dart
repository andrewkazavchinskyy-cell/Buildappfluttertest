import 'dart:async';

import 'package:battle_decks/providers/providers.dart';
import 'package:battle_decks/screens/screens.dart';
import 'package:battle_decks/services/services.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:in_app_review/in_app_review.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

final InAppReview inAppReview = InAppReview.instance;
// final RouteObserver<ModalRoute<void>> routeObserver =
//     RouteObserver<ModalRoute<void>>();

Future<void> launchUri(String url) async {
  if (!await launchUrl(Uri.parse(url))) {
    throw Exception('Could not launch $url');
  }
}

Future<void> rateUs() async {
  if (await inAppReview.isAvailable()) {
    await inAppReview.requestReview();
  } else {
    await inAppReview.openStoreListing(
      appStoreId: '6753083300',
      microsoftStoreId: null,
    );
  }
}

void main() {
  runZonedGuarded(
    () async {
      WidgetsFlutterBinding.ensureInitialized();

      await MobileAds.instance.initialize();

      final preferences = await SharedPreferences.getInstance();
      final preferencesService = PreferencesService(preferences);

      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitUp,
        DeviceOrientation.portraitDown,
      ]);

      runApp(
        ScreenUtilInit(
          designSize: Size(393, 852),
          builder: (context, child) =>
              MyApp(preferencesService: preferencesService),
        ),
      );
    },
    (error, stack) {
      print(error);
      print(stack);
    },
  );
}

class MyApp extends StatefulWidget {
  const MyApp({super.key, required this.preferencesService});

  final PreferencesService preferencesService;

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late final router = GoRouter(
    // observers: [routeObserver],
    initialLocation: '/loading',
    routes: [
      GoRoute(path: '/loading', builder: (context, state) => LoadingScreen()),
      GoRoute(
        path: '/',
        builder: (context, state) {
          return HomeScreen();
        },
        routes: [
          GoRoute(path: 'info', builder: (context, state) => HowToPlayScreen()),
          GoRoute(
            path: 'tutorial',
            builder: (context, state) => TutorialScreen(),
          ),
          GoRoute(path: 'solo', builder: (context, state) => SoloGameScreen()),
          GoRoute(
            path: 'multiplayer',
            builder: (context, state) => MultiplayerGameConfigScreen(),
          ),
          GoRoute(
            path: 'game',
            builder: (context, state) => MultiplayerGameScreen(),
          ),
        ],
      ),
    ],
  );

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider.value(value: widget.preferencesService),
        ChangeNotifierProvider(
          create: (context) => ConfigProvider(widget.preferencesService),
        ),
      ],
      child: MaterialApp.router(
        title: 'Flutter Demo',
        routerConfig: router,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        ),
      ),
    );
  }
}
