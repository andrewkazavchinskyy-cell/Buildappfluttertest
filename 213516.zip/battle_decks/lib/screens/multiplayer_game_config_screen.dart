import 'package:battle_decks/providers/providers.dart';
import 'package:battle_decks/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../widgets/widgets.dart';

class MultiplayerGameConfigScreen extends StatefulWidget {
  const MultiplayerGameConfigScreen({super.key});

  @override
  State<MultiplayerGameConfigScreen> createState() =>
      _MultiplayerGameConfigScreenState();
}

class _MultiplayerGameConfigScreenState
    extends State<MultiplayerGameConfigScreen> {
  int _selectedPlayerCount = 2;
  int _coinsPerPlayer = 1000;

  bool _secretWaggers = true;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.backgroundPrimary,
      child: SafeArea(
        child: Column(
          children: [
            Gap(24.h),
            Row(
              children: [
                Image.asset(
                  'assets/png/multiplayer_title.png',
                  width: 236.r,
                  height: 56.r,
                  fit: BoxFit.fill,
                ),
                Spacer(),
                CustomIconButton(
                  icon: 'assets/png/close.png',
                  onTap: context.pop,
                ),
                SizedBox(width: 16.w),
              ],
            ),
            Gap(46.h),
            SizedBox(
              width: 361.w,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Number of players",
                        style: AppTextStyles.headerSSecondary.copyWith(
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(
                        width: 156.w,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: List.generate(3, (index) {
                            final value = index + 2;
                            final selected = _selectedPlayerCount == value;
                            return GestureDetector(
                              onTap: () =>
                                  setState(() => _selectedPlayerCount = value),
                              child: Container(
                                width: 44.r,
                                height: 44.r,
                                decoration: BoxDecoration(
                                  color: AppColors.layersLayer1,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    width: 3.sp,
                                    color: selected
                                        ? AppColors.strokeStroke3
                                        : AppColors.layersLayer2,
                                  ),
                                ),
                                alignment: Alignment.center,
                                padding: EdgeInsets.only(bottom: 5.h),
                                child: Text(
                                  "$value",
                                  style: AppTextStyles.headerMSecondary
                                      .copyWith(
                                        color: selected
                                            ? null
                                            : AppColors.textSecondary,
                                      ),
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                    ],
                  ),
                  Gap(32.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Coins per player",
                        style: AppTextStyles.headerSSecondary.copyWith(
                          color: Colors.white,
                        ),
                      ),
                      CustomNumberInput(
                        number: _coinsPerPlayer,
                        onChanged: (value) => _coinsPerPlayer = value,
                      ),
                    ],
                  ),
                  Gap(32.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Secret waggers",
                        style: AppTextStyles.headerSSecondary.copyWith(
                          color: Colors.white,
                        ),
                      ),
                      CustomCheckBox(
                        isTapped: _secretWaggers,
                        onTap: () {
                          _secretWaggers = !_secretWaggers;
                          setState(() {});
                        },
                      ),
                    ],
                  ),
                  Gap(32.h),
                  Text(
                    "Each Player will set their Battle Bond one by one, in the end cards will be given to each player, and someone becomes a winner.",
                    style: AppTextStyles.bodyPrimary,
                  ),
                ],
              ),
            ),
            Spacer(),
            Button3(
              width: 361.w,
              text: "Start the Game",
              bgColor: AppColors.layersLayer3,
              strokeColor: AppColors.strokeStroke3,
              onTap: () {
                if (_coinsPerPlayer < 100 || _coinsPerPlayer > 100000) return;
                context.read<ConfigProvider>().startGame(
                  _selectedPlayerCount,
                  _coinsPerPlayer,
                  _secretWaggers,
                );
                context.go('/game');
              },
            ),
            Gap(24.h),
          ],
        ),
      ),
    );
  }
}
