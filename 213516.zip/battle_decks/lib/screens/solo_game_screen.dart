import 'dart:math';
import 'package:battle_decks/providers/providers.dart';
import 'package:battle_decks/utils/utils.dart';
import 'package:battle_decks/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:provider/provider.dart';

class SoloGameScreen extends StatelessWidget {
  const SoloGameScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (BuildContext context) {
        return SoloGameProvider(
          (onBattle, onSurrender) =>
              showBattleDialog(context, onBattle, onSurrender),
          (message) => CustomNotification.show(context, message: message),
          (value) => showResult(context, value),
          Provider.of(context, listen: false),
        );
      },
      child: Consumer<SoloGameProvider>(
        builder: (context, value, child) {
          return Material(
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.asset('assets/png/game.png', fit: BoxFit.cover),
                ),
                Positioned.fill(
                  child: SafeArea(
                    child: Column(
                      children: [
                        Gap(16.h),
                        SizedBox(
                          width: 361.w,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              CoinsWidget(),
                              CustomIconButton(
                                icon: "assets/png/menu.png",
                                onTap: () => showMenu(context),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 370.r,
                          height: 582.r,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                bottom: 0.r,
                                child: Image.asset(
                                  'assets/png/table.png',
                                  width: 304.r,
                                  height: 533.r,
                                  fit: BoxFit.fill,
                                ),
                              ),
                              Positioned(
                                bottom: 45.r,
                                child: Column(
                                  children: [
                                    Button4(
                                      text: "Battle Bond:",
                                      chips: value.battleBond,
                                      sum: value.battleBondSum,
                                      onTap: value.addBattleBond,
                                    ),
                                    Button4(
                                      text: "Tie:",
                                      chips: value.tie,
                                      leftPadding: 51.w,
                                      rightPadding: 41.w,
                                      sum: value.tieSum,
                                      onTap: value.addTie,
                                    ),
                                  ],
                                ),
                              ),
                              Positioned(
                                top: 150.r,
                                child: Column(
                                  children: [
                                    value.gameCard2 == null
                                        ? SizedBox(width: 64.r, height: 90.r)
                                        : Image.asset(
                                            value.gameCard2!.asset,
                                            width: 64.r,
                                            height: 90.r,
                                            fit: BoxFit.fill,
                                          ),
                                    Gap(8.h),
                                    SizedBox(
                                      width: 90.r,
                                      height: 64.r,
                                      child: FittedBox(
                                        fit: BoxFit.none,
                                        child: Transform.rotate(
                                          angle: -pi / 2,
                                          child: Image.asset(
                                            'assets/png/card_symbol.png',
                                            width: 64.r,
                                            height: 90.r,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Gap(8.h),
                                    value.gameCard1 == null
                                        ? SizedBox(width: 64.r, height: 90.r)
                                        : Image.asset(
                                            value.gameCard1!.asset,
                                            width: 64.r,
                                            height: 90.r,
                                            fit: BoxFit.fill,
                                          ),
                                  ],
                                ),
                              ),
                              Positioned(
                                top: 0,
                                child: IgnorePointer(
                                  child: Image.asset(
                                    'assets/png/solo_frame.png',
                                    width: 370.r,
                                    height: 582.r,
                                    fit: BoxFit.fill,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Gap(5.h),
                        if (!value.gameOver)
                          SizedBox(
                            width: 294.w,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: List.generate(chipsList.length, (
                                index,
                              ) {
                                final chip = chipsList[index];
                                final selected = chip.id == value.chipModel.id;

                                if (selected) {
                                  return Transform.scale(
                                    scale: 1.6,
                                    child: Image.asset(
                                      chip.selectedAsset,
                                      width: 48.r,
                                      height: 48.r,
                                      fit: BoxFit.fill,
                                    ),
                                  );
                                }

                                return GestureDetector(
                                  onTap: () => value.selectedChip(chip),
                                  child: Image.asset(
                                    chip.asset,
                                    width: 48.r,
                                    height: 48.r,
                                    fit: BoxFit.fill,
                                  ),
                                );
                              }),
                            ),
                          ),
                        Spacer(),
                        SizedBox(
                          width: 361.w,
                          child: value.gameOver
                              ? Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Button3(
                                      text: "New Game",
                                      width: 176.w,
                                      bgColor: AppColors.layersLayer2,
                                      strokeColor: AppColors.strokeStroke1,
                                      onTap: value.onNewGame,
                                    ),
                                    Button3(
                                      text: "Same Bond",
                                      width: 176.w,
                                      bgColor: AppColors.layersLayer3,
                                      strokeColor: AppColors.strokeStroke3,
                                      onTap: value.onSameBond,
                                    ),
                                  ],
                                )
                              : Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Button3(
                                      text: "Undo",
                                      width: 98.w,
                                      isEnabled: value.canUndo,
                                      bgColor: AppColors.layersLayer2,
                                      strokeColor: AppColors.strokeStroke1,
                                      onTap: value.undo,
                                    ),
                                    Button3(
                                      text: "Clear",
                                      width: 95.w,
                                      isEnabled: value.canClear,
                                      bgColor: AppColors.layersLayer2,
                                      strokeColor: AppColors.strokeStroke1,
                                      onTap: value.clear,
                                    ),
                                    Button3(
                                      text: "Deal",
                                      width: 152.w,
                                      isEnabled: value.canDeal,
                                      bgColor: AppColors.layersLayer3,
                                      strokeColor: AppColors.strokeStroke3,
                                      onTap: value.deal,
                                    ),
                                  ],
                                ),
                        ),
                        Gap(10.h),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void showMenu(BuildContext context) {
    showDialog(
      context: context,
      barrierColor: AppColors.backgroundSecondary.withValues(alpha: 0.7),
      builder: (context) {
        return Center(child: const MenuDialog());
      },
    );
  }

  void showBattleDialog(
    BuildContext context,
    VoidCallback? onBattle,
    VoidCallback? onSurrender,
  ) {
    showDialog(
      context: context,
      barrierColor: AppColors.backgroundSecondary.withValues(alpha: 0.7),
      barrierDismissible: false,
      builder: (context) {
        return Center(
          child: BattleDialog(onBattle: onBattle, onSurrender: onSurrender),
        );
      },
    );
  }

  void showResult(BuildContext context, int value) {
    showDialog(
      context: context,
      barrierColor: AppColors.backgroundSecondary.withValues(alpha: 0.7),
      builder: (context) {
        return Center(child: ResultDialog(value: value));
      },
    );
  }
}
