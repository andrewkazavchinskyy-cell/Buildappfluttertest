import 'package:battle_decks/utils/utils.dart';
import 'package:battle_decks/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';

class HowToPlayScreen extends StatelessWidget {
  const HowToPlayScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.backgroundPrimary,
      child: SafeArea(
        child: Column(
          children: [
            Gap(24.h),
            Row(
              children: [
                Image.asset(
                  'assets/png/how_to_play_title.png',
                  width: 236.r,
                  height: 56.r,
                  fit: BoxFit.fill,
                ),
                Spacer(),
                CustomIconButton(
                  icon: "assets/png/close.png",
                  onTap: context.pop,
                ),
                Gap(16.w),
              ],
            ),
            Gap(24.h),
            SizedBox(
              width: 361.w,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Place Your Battle Bond ",
                    style: AppTextStyles.headerSSecondary,
                  ),
                  Text(
                    "Select your main stake to start the duel.",
                    style: AppTextStyles.bodyPrimary,
                  ),
                  Gap(12.h),
                  Text(
                    "Optional Tie Stake",
                    style: AppTextStyles.headerSSecondary,
                  ),
                  Text(
                    "You can also place a wager on a Tie for higher rewards. This kind of bet can be made only after Battle Bond .",
                    style: AppTextStyles.bodyPrimary,
                  ),
                  Gap(12.h),
                  Text(
                    "Reveal the Cards ",
                    style: AppTextStyles.headerSSecondary,
                  ),
                  Text(
                    "Both you and your opponent reveal your cards.",
                    style: AppTextStyles.bodyPrimary,
                  ),
                  Gap(12.h),
                  Text(
                    "Win, Lose, or Tie:",
                    style: AppTextStyles.headerSSecondary,
                  ),
                  Text(
                    """If your card is higher — you win your Battle Bond.
If it's lower — you lose your Battle Bond and the Tie stake.
If it's a Tie — you win 10x your Tie stake and can: 
Collect Half of Battle Bond — take 50% of your main stake. 
Go to Battle — double your stake and enter a new duel.""",
                    style: AppTextStyles.bodyPrimary,
                  ),
                  Gap(12.h),
                  Text(
                    "Battle Round (if chosen):",
                    style: AppTextStyles.headerSSecondary,
                  ),
                  Text(
                    "Your main stake is automatically doubled.\nNew cards are revealed to determine the final winner.",
                    style: AppTextStyles.bodyPrimary,
                  ),
                  Gap(12.h),
                  Text(
                    "Repeat & Conquer!",
                    style: AppTextStyles.headerSSecondary,
                  ),
                  Gap(74.h),
                  Center(
                    child: Image.asset(
                      'assets/png/card_symbol.png',
                      width: 64.r,
                      height: 90.r,
                      fit: BoxFit.fill,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
