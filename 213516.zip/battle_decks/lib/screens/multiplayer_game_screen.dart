import 'dart:math';

import 'package:battle_decks/models/models.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:provider/provider.dart';

import '../providers/providers.dart';
import '../utils/utils.dart';
import '../widgets/widgets.dart';

class MultiplayerGameScreen extends StatelessWidget {
  const MultiplayerGameScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (BuildContext context) {
        return MultiplayerGameProvider(
          (player) => showPlayer(context, player),
          Provider.of(context, listen: false),
          (message) => CustomNotification.show(context, message: message),
          (player) => showResult(context, player),
          (players, battle, surrender) =>
              showBattleDialog(context, players, battle, surrender),
        );
      },
      child: Consumer<MultiplayerGameProvider>(
        builder: (context, value, child) {
          return Material(
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.asset('assets/png/game.png', fit: BoxFit.cover),
                ),
                Positioned.fill(
                  child: SafeArea(
                    child: Column(
                      children: [
                        Gap(16.h),
                        SizedBox(
                          width: 361.w,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              value.gameOver || value.extraGame
                                  ? Container(
                                      width: 101.w,
                                      height: 44.h,
                                      decoration: BoxDecoration(
                                        color: AppColors.layersLayer1,
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          width: 3.sp,
                                          color: AppColors.strokeStroke1,
                                        ),
                                      ),
                                      alignment: Alignment.center,
                                      child: Text(
                                        "Results",
                                        style: AppTextStyles.headerMSecondary,
                                      ),
                                    )
                                  : CoinsWidget2(playerModel: value.player),
                              CustomIconButton(
                                icon: "assets/png/menu.png",
                                onTap: () => showMenu(context),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 370.r,
                          height: 538.r,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Positioned(
                                bottom: 0.r,
                                child: Image.asset(
                                  'assets/png/table.png',
                                  width: 304.r,
                                  height: 533.r,
                                  fit: BoxFit.fill,
                                ),
                              ),
                              if (!value.gameOver && !value.extraGame)
                                Positioned(
                                  bottom: 45.r,
                                  child: Column(
                                    children: [
                                      Button4(
                                        text: "Battle Bond:",
                                        chips: value.player.chips,
                                        sum: value.player.chipsSum,
                                        onTap: value.addBattleBond,
                                      ),
                                      Button4(
                                        text: "Tie:",
                                        chips: value.player.tieChips,
                                        leftPadding: 51.w,
                                        rightPadding: 41.w,
                                        sum: value.player.tieChipsSum,
                                        onTap: value.addTie,
                                      ),
                                    ],
                                  ),
                                ),
                              Positioned(
                                top: 262.r,
                                child: SizedBox(
                                  width: 90.r,
                                  height: 64.r,
                                  child: FittedBox(
                                    fit: BoxFit.none,
                                    child: Transform.rotate(
                                      angle: -pi / 2,
                                      child: Image.asset(
                                        'assets/png/card_symbol.png',
                                        width: 64.r,
                                        height: 90.r,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              if (value.gameOver || value.extraGame)
                                Positioned.fill(
                                  child: _buildCards(value.players),
                                ),
                              IgnorePointer(
                                child: Image.asset(
                                  'assets/png/multiplayer_frame.png',
                                  width: 370.r,
                                  height: 538.r,
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Gap(5.h),
                        if (!value.gameOver)
                          SizedBox(
                            width: 294.w,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: List.generate(chipsList.length, (
                                index,
                              ) {
                                final chip = chipsList[index];
                                final selected = chip.id == value.chipModel.id;

                                if (selected) {
                                  return Transform.scale(
                                    scale: 1.6,
                                    child: Image.asset(
                                      chip.selectedAsset,
                                      width: 48.r,
                                      height: 48.r,
                                      fit: BoxFit.fill,
                                    ),
                                  );
                                }

                                return GestureDetector(
                                  onTap: () => value.selectChip(chip),
                                  child: Image.asset(
                                    chip.asset,
                                    width: 48.r,
                                    height: 48.r,
                                    fit: BoxFit.fill,
                                  ),
                                );
                              }),
                            ),
                          ),
                        Spacer(),
                        SizedBox(
                          width: 361.w,
                          child: value.gameOver
                              ? Button3(
                                  text: "New Game",
                                  width: 361.w,
                                  bgColor: AppColors.layersLayer3,
                                  strokeColor: AppColors.strokeStroke3,
                                  onTap: value.onNewGame,
                                )
                              : Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Button3(
                                      text: "Undo",
                                      width: 98.w,
                                      isEnabled: value.canUndo,
                                      bgColor: AppColors.layersLayer2,
                                      strokeColor: AppColors.strokeStroke1,
                                      onTap: value.undo,
                                    ),
                                    Button3(
                                      text: "Clear",
                                      width: 95.w,
                                      isEnabled: value.canClear,
                                      bgColor: AppColors.layersLayer2,
                                      strokeColor: AppColors.strokeStroke1,
                                      onTap: value.clear,
                                    ),
                                    Button3(
                                      text: "Done",
                                      width: 152.w,
                                      isEnabled: value.canDeal,
                                      bgColor: AppColors.layersLayer3,
                                      strokeColor: AppColors.strokeStroke3,
                                      onTap: value.deal,
                                    ),
                                  ],
                                ),
                        ),
                        Gap(10.h),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void showMenu(BuildContext context) {
    showDialog(
      context: context,
      barrierColor: AppColors.backgroundSecondary.withValues(alpha: 0.7),
      builder: (context) {
        return Center(child: const MenuDialog());
      },
    );
  }

  void showPlayer(BuildContext context, PlayerModel player) {
    showDialog(
      context: context,
      barrierColor: AppColors.backgroundSecondary.withValues(alpha: 0.7),
      builder: (context) {
        return Center(child: PlayerDialog(playerModel: player));
      },
    );
  }

  void showBattleDialog(
    BuildContext context,
    List<PlayerModel> players,
    VoidCallback? onBattle,
    VoidCallback? onSurrender,
  ) {
    showDialog(
      context: context,
      barrierColor: AppColors.backgroundSecondary.withValues(alpha: 0.7),
      barrierDismissible: false,
      builder: (context) {
        return Center(
          child: BattleDialog2(
            players: players,
            onBattle: onBattle,
            onSurrender: onSurrender,
          ),
        );
      },
    );
  }

  void showResult(BuildContext context, PlayerModel player) {
    showDialog(
      context: context,
      barrierColor: AppColors.backgroundSecondary.withValues(alpha: 0.7),
      builder: (context) {
        return Center(child: ResultDialog2(playerModel: player));
      },
    );
  }

  Widget _buildCards(List<PlayerModel> players) {
    if (players.length == 2) {
      final player1 = players[0];
      final player2 = players[1];
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Gap(50.h),
          _buildBody1(player1),
          SizedBox(height: 88.r),
          _buildBody2(player2),
        ],
      );
    }
    if (players.length == 3) {
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Gap(50.h),
          SizedBox(
            width: 192.w,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(2, (index) {
                final player = players[index];
                return _buildBody1(player);
              }),
            ),
          ),
          SizedBox(height: 88.r),
          _buildBody2(players.last),
        ],
      );
    }
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Gap(50.h),
        SizedBox(
          width: 192.w,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(2, (index) {
              final player = players[index];
              return _buildBody1(player);
            }),
          ),
        ),
        SizedBox(height: 88.r),
        SizedBox(
          width: 192.w,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(2, (index) {
              final player = players[index + 2];
              return _buildBody2(player);
            }),
          ),
        ),
      ],
    );
  }

  Widget _buildBody1(PlayerModel player) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 5.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            color: AppColors.accentPrimary,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.only(bottom: 4.h),
                child: Text(
                  "${player.bank}",
                  style: AppTextStyles.bodyPrimary.copyWith(
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
              Gap(4.w),
              Image.asset(
                'assets/png/coin.png',
                width: 16.r,
                height: 16.r,
                fit: BoxFit.fill,
              ),
            ],
          ),
        ),
        Gap(4.h),
        Text(
          player.name,
          style: AppTextStyles.headerSPrimaryBold.copyWith(
            color: AppColors.textPrimary,
          ),
        ),
        Gap(8.h),
        if (player.gameCard != null)
          Image.asset(
            player.gameCard!.asset,
            width: 64.r,
            height: 90.r,
            fit: BoxFit.fill,
          ),
      ],
    );
  }

  Widget _buildBody2(PlayerModel player) {
    return Column(
      children: [
        if (player.gameCard != null)
          Image.asset(
            player.gameCard!.asset,
            width: 64.r,
            height: 90.r,
            fit: BoxFit.fill,
          ),
        Gap(8.h),
        Text(
          player.name,
          style: AppTextStyles.headerSPrimaryBold.copyWith(
            color: AppColors.textPrimary,
          ),
        ),
        Gap(4.h),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 5.h),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            color: AppColors.accentPrimary,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: EdgeInsets.only(bottom: 4.h),
                child: Text(
                  "${player.bank}",
                  style: AppTextStyles.bodyPrimary.copyWith(
                    color: AppColors.textPrimary,
                  ),
                ),
              ),
              Gap(4.w),
              Image.asset(
                'assets/png/coin.png',
                width: 16.r,
                height: 16.r,
                fit: BoxFit.fill,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
