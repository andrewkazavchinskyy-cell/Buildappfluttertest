import 'dart:math';

import 'package:battle_decks/services/services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../utils/utils.dart';
import '../widgets/widgets.dart';

class TutorialScreen extends StatefulWidget {
  const TutorialScreen({super.key});

  @override
  State<TutorialScreen> createState() => _TutorialScreenState();
}

class _TutorialScreenState extends State<TutorialScreen> {
  int _step = 0;

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned.fill(
            child: Image.asset('assets/png/game.png', fit: BoxFit.cover),
          ),
          Positioned.fill(
            child: SafeArea(
              child: Column(
                children: [
                  Gap(16.h),
                  SizedBox(
                    width: 361.w,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CoinsWidget(),
                        CustomIconButton(icon: "assets/png/menu.png"),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 370.r,
                    height: 582.r,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Positioned(
                          bottom: 0.r,
                          child: Image.asset(
                            'assets/png/table.png',
                            width: 304.r,
                            height: 533.r,
                            fit: BoxFit.fill,
                          ),
                        ),
                        Positioned(
                          bottom: 45.r,
                          child: Column(
                            children: [
                              Button4(
                                text: "Battle Bond:",
                                chips: _step == 2 ? [chipsList.first] : [],
                                sum: _step == 2 ? 10 : 0,
                              ),
                              Button4(
                                text: "Tie:",
                                chips: [],
                                leftPadding: 51.w,
                                rightPadding: 41.w,
                                sum: 0,
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          top: 150.r,
                          child: Column(
                            children: [
                              SizedBox(width: 64.r, height: 90.r),
                              Gap(8.h),
                              SizedBox(
                                width: 90.r,
                                height: 64.r,
                                child: FittedBox(
                                  fit: BoxFit.none,
                                  child: Transform.rotate(
                                    angle: -pi / 2,
                                    child: Image.asset(
                                      'assets/png/card_symbol.png',
                                      width: 64.r,
                                      height: 90.r,
                                      fit: BoxFit.fill,
                                    ),
                                  ),
                                ),
                              ),
                              Gap(8.h),
                              SizedBox(width: 64.r, height: 90.r),
                            ],
                          ),
                        ),
                        Positioned(
                          top: 0,
                          child: IgnorePointer(
                            child: Image.asset(
                              'assets/png/solo_frame.png',
                              width: 370.r,
                              height: 582.r,
                              fit: BoxFit.fill,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Gap(5.h),
                  SizedBox(
                    width: 294.w,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: List.generate(chipsList.length, (index) {
                        final chip = chipsList[index];
                        final selected = chip.id == 0;

                        if (selected) {
                          return Transform.scale(
                            scale: 1.6,
                            child: Image.asset(
                              chip.selectedAsset,
                              width: 48.r,
                              height: 48.r,
                              fit: BoxFit.fill,
                            ),
                          );
                        }

                        return Image.asset(
                          chip.asset,
                          width: 48.r,
                          height: 48.r,
                          fit: BoxFit.fill,
                        );
                      }),
                    ),
                  ),
                  Spacer(),
                  SizedBox(
                    width: 361.w,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Button3(
                          text: "Undo",
                          width: 98.w,
                          isEnabled: _step == 2,
                          bgColor: AppColors.layersLayer2,
                          strokeColor: AppColors.strokeStroke1,
                        ),
                        Button3(
                          text: "Clear",
                          width: 95.w,
                          isEnabled: _step == 2,
                          bgColor: AppColors.layersLayer2,
                          strokeColor: AppColors.strokeStroke1,
                        ),
                        Button3(
                          text: "Deal",
                          width: 152.w,
                          isEnabled: _step == 2,
                          bgColor: AppColors.layersLayer3,
                          strokeColor: AppColors.strokeStroke3,
                        ),
                      ],
                    ),
                  ),
                  Gap(10.h),
                ],
              ),
            ),
          ),
          if (_step == 0)
            Positioned(
              left: 90.w,
              bottom: 154.h,
              child: SizedBox(
                width: 259.w,
                height: 123.h,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    _buildButton(width: 241.w, text: "Select Chip"),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Transform.rotate(
                        angle: -(pi / 180) * 100,
                        child: Image.asset(
                          'assets/png/pointer.png',
                          width: 51.r,
                          height: 51.r,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (_step == 1)
            Positioned(
              left: 60.w,
              bottom: 340.h,
              child: SizedBox(
                width: 293.w,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildButton(width: 273.w, text: "Select Wagger"),
                    Padding(
                      padding: EdgeInsets.only(left: 20.w),
                      child: Transform.rotate(
                        angle: -(pi / 180) * 154,
                        child: Image.asset(
                          'assets/png/pointer.png',
                          width: 51.r,
                          height: 51.r,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (_step == 2)
            Positioned(
              right: 14.w,
              bottom: 100.h,
              child: SizedBox(
                width: 293.w,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    _buildButton(
                      width: 192.w,
                      text: "Deal Cards",
                      hasNext: false,
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 20.w),
                      child: Transform.rotate(
                        angle: -(pi / 180) * 154,
                        child: Image.asset(
                          'assets/png/pointer.png',
                          width: 51.r,
                          height: 51.r,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildButton({
    required double width,
    required String text,
    bool hasNext = true,
  }) {
    return Container(
      width: width,
      height: 68.h,
      decoration: BoxDecoration(
        color: AppColors.layersLayer1,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(width: 3.sp, color: AppColors.layersLayer2),
      ),
      padding: EdgeInsets.only(right: 12.w),
      child: Row(
        children: [
          Expanded(
            child: Center(
              child: Text(text, style: AppTextStyles.headerMSecondary),
            ),
          ),
          Row(
            children: [
              if (hasNext) ...[
                CustomIconButton(icon: "assets/png/next.png", onTap: next),
                Gap(4.w),
              ],
              CustomIconButton(icon: "assets/png/close.png", onTap: close),
            ],
          ),
        ],
      ),
    );
  }

  void next() {
    if (_step == 2) {
      context.read<PreferencesService>().setTutorial();
      context.go('/solo');
      return;
    }

    _step++;
    setState(() {});
  }

  void close() {
    if (_step == 2) context.read<PreferencesService>().setTutorial();
    context.go('/solo');
  }
}
