import 'package:battle_decks/providers/providers.dart';
import 'package:battle_decks/services/services.dart';
import 'package:battle_decks/utils/utils.dart';
import 'package:battle_decks/widgets/widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../main.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with RouteAware {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (context.read<ConfigProvider>().coins == 0) showAdDialog();
    });
  }

  // @override
  // void didChangeDependencies() {
  //   super.didChangeDependencies();
  //   routeObserver.subscribe(this, ModalRoute.of(context)!);
  // }
  //
  // @override
  // void dispose() {
  //   routeObserver.unsubscribe(this);
  //   super.dispose();
  // }
  //
  // @override
  // void didPopNext() {
  //   if (context.read<ConfigProvider>().coins == 0) {
  //     WidgetsBinding.instance.addPostFrameCallback((_) => showAdDialog());
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    final tut = context.read<PreferencesService>().getTutorial();
    return AnnotatedRegion(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.dark,
      ),
      child: Material(
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset('assets/png/home.png', fit: BoxFit.cover),
            ),
            Positioned.fill(
              child: SafeArea(
                child: Column(
                  children: [
                    Gap(24.h),
                    SizedBox(
                      width: 361.w,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          CoinsWidget(),
                          CustomIconButton(
                            icon: 'assets/png/settings.png',
                            onTap: showSettings,
                          ),
                        ],
                      ),
                    ),
                    Spacer(),
                    SizedBox(
                      width: 317.w,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () => context.go('/info'),
                            child: Image.asset(
                              'assets/png/how_to_play.png',
                              width: 96.r,
                              height: 94.r,
                              fit: BoxFit.fill,
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (tut) {
                                context.go('/tutorial');
                                return;
                              }
                              context.go('/solo');
                            },
                            child: Image.asset(
                              'assets/png/play_solo.png',
                              width: 96.r,
                              height: 94.r,
                              fit: BoxFit.fill,
                            ),
                          ),
                          GestureDetector(
                            onTap: () => context.go('/multiplayer'),
                            child: Image.asset(
                              'assets/png/multiplayer.png',
                              width: 96.r,
                              height: 94.r,
                              fit: BoxFit.fill,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 24.h),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void showSettings() {
    showDialog(
      context: context,
      barrierColor: AppColors.backgroundSecondary.withValues(alpha: 0.7),
      builder: (context) {
        return Center(child: SettingsDialog());
      },
    );
  }

  void showAdDialog() {
    showDialog(
      context: context,
      barrierColor: AppColors.backgroundSecondary.withValues(alpha: 0.7),
      builder: (context) {
        return Center(child: AdDialog());
      },
    );
  }
}
