import 'package:battle_decks/services/services.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';

class ConfigProvider extends ChangeNotifier {
  final PreferencesService _preferencesService;

  int _coins = 100;

  int get coins => _coins;

  bool _music = true;

  bool _noti = true;

  bool get noti => _noti;

  final AudioPlayer _player = AudioPlayer();

  ConfigProvider(this._preferencesService) {
    init();
  }

  bool get music => _music;

  int _playersNumber = 2;

  int _coinsPerPerson = 1000;

  bool _secretWaggers = true;

  int get playersNumber => _playersNumber;

  int get coinsPerPerson => _coinsPerPerson;

  bool get secretWaggers => _secretWaggers;

  void init() async {
    _coins = _preferencesService.getCoins();
    _music = _preferencesService.getMusic();
    _noti = _preferencesService.getNoti();

    await _player.setAsset('assets/audio/knight.mp3');
    if (_music) await _playMusic();
  }

  Future<void> _playMusic() async {
    try {
      await _player.play();
      _player.setLoopMode(LoopMode.all);
    } catch (e) {
      print(e);
    }
  }

  void toggleMusic() async {
    _music = !_music;
    notifyListeners();
    await _preferencesService.setMusic(_music);
    _music ? await _playMusic() : await _player.stop();
  }

  void addCoins(int value) async {
    _coins += value;
    await _preferencesService.setCoins(_coins);
    notifyListeners();
  }

  void startGame(int playersNumber, int coinsPerPerson, bool secretWaggers) {
    _playersNumber = playersNumber;
    _coinsPerPerson = coinsPerPerson;
    _secretWaggers = secretWaggers;
  }

  void toggleNoti(bool value) async {
    _noti = value;
    await _preferencesService.setNoti(_noti);
    notifyListeners();
  }
}
