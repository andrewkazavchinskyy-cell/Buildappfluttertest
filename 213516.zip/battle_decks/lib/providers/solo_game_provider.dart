import 'dart:math';
import 'package:battle_decks/models/models.dart';
import 'package:battle_decks/providers/providers.dart';
import 'package:battle_decks/utils/utils.dart';
import 'package:flutter/material.dart';

enum BetAction { battleBond, tie }

class SoloGameProvider extends ChangeNotifier {
  SoloGameProvider(
    this.showBattleDialog,
    this.showLimit,
    this.showResult,
    this._configProvider,
  ) {
    init();
  }

  final ConfigProvider _configProvider;
  final void Function(VoidCallback? onBattle, VoidCallback? onSurrender)
  showBattleDialog;
  final void Function(String)? showLimit;
  final void Function(int)? showResult;

  ChipModel _chipModel = ChipModel.empty();

  ChipModel get chipModel => _chipModel;

  List<ChipModel> _battleBond = [];

  List<ChipModel> get battleBond => _battleBond;

  final List<ChipModel> _tie = [];

  List<ChipModel> get tie => _tie;

  final List<BetAction> _betActions = [];

  List<BetAction> get betActions => _betActions;

  int get battleBondSum => _battleBond.isEmpty
      ? 0
      : _battleBond.fold(0, (sum, chip) => sum + chip.value);

  int get tieSum =>
      _tie.isEmpty ? 0 : _tie.fold(0, (sum, chip) => sum + chip.value);

  bool get canUndo => _betActions.isNotEmpty && !_gameOver && !_extraGame;

  bool get canClear =>
      (_battleBond.isNotEmpty || _tie.isNotEmpty) && !_gameOver && !_extraGame;

  bool get canDeal =>
      ((_battleBond.isNotEmpty || _tie.isNotEmpty) && !_gameOver) || _extraGame;

  GameCard? _gameCard1;
  GameCard? _gameCard2;

  GameCard? get gameCard1 => _gameCard1;

  GameCard? get gameCard2 => _gameCard2;

  bool _gameOver = false;

  bool get gameOver => _gameOver;

  bool _extraGame = false;

  void init() {
    _gameOver = false;
    _chipModel = ChipModel.empty();
    _battleBond.clear();
    _tie.clear();
    _betActions.clear();
  }

  void selectedChip(ChipModel chip) {
    _chipModel = chip;
    notifyListeners();
  }

  void addBattleBond() {
    if (_gameOver) return;
    if (_chipModel.id == -1) return;
    if (_configProvider.coins < tieSum + battleBondSum + _chipModel.value) {
      showLimit?.call("Not Enough Coins");
      return;
    }
    if (battleBondSum + _chipModel.value > 10000) {
      showLimit?.call("Battle Bond Limit");
      return;
    }
    _battleBond.add(_chipModel);
    _betActions.add(BetAction.battleBond);
    notifyListeners();
  }

  void addTie() {
    if (_gameOver) return;
    if (_chipModel.id == -1) return;
    if (_configProvider.coins < tieSum + battleBondSum + _chipModel.value) {
      showLimit?.call("Not Enough Coins");
      return;
    }
    if (tieSum + _chipModel.value > 10000) {
      showLimit?.call("Tie Limit");
      return;
    }
    _tie.add(_chipModel);
    _betActions.add(BetAction.tie);
    notifyListeners();
  }

  void undo() {
    if (!canUndo) return;
    final lastBetAction = _betActions.last;

    if (lastBetAction == BetAction.battleBond) {
      _battleBond.removeLast();
    } else if (lastBetAction == BetAction.tie) {
      _tie.removeLast();
    }
    _betActions.removeLast();
    notifyListeners();
  }

  void clear() {
    if (!canClear) return;
    init();
    notifyListeners();
  }

  void deal() async {
    if (!canDeal) return;
    if(_configProvider.coins < battleBondSum + tieSum) {
      showLimit?.call("Not Enough Coins");
      return;
    }

    _gameOver = true;
    int rand1 = Random().nextInt(gameCards.length);
    int rand2 = Random().nextInt(gameCards.length);

    while (rand1 == rand2) {
      rand2 = Random().nextInt(gameCards.length);
    }

    _gameCard1 = gameCards[rand1];
    _gameCard2 = gameCards[rand2];

    _configProvider.addCoins(-battleBondSum);
    _configProvider.addCoins(-tieSum);

    notifyListeners();

    await Future.delayed(const Duration(seconds: 1));

    if (_gameCard1!.rank == _gameCard2!.rank) {
      _configProvider.addCoins(tieSum * 10);
      showBattleDialog(_onBattle, _onSurrender);
    } else if (_gameCard1!.rank > _gameCard2!.rank) {
      showResult?.call(battleBondSum);
      _configProvider.addCoins(battleBondSum * 2);
    } else {
      showResult?.call(-battleBondSum);
    }
  }

  void _onBattle() async {
    if (_configProvider.coins < battleBondSum) {
      showLimit?.call("Not Enough Coins");
      return;
    }
    _extraGame = true;
    _battleBond = [..._battleBond, ..._battleBond];
    _gameCard1 = null;
    _gameCard2 = null;
    notifyListeners();

    await Future.delayed(const Duration(seconds: 1));
    deal();
  }

  void _onSurrender() {
    showResult?.call(tieSum * 10);
    _configProvider.addCoins(battleBondSum ~/ 2);
  }

  void onNewGame() {
    if (!_gameOver) return;
    init();
    _extraGame = false;
    _gameCard1 = null;
    _gameCard2 = null;
    notifyListeners();
  }

  void onSameBond() async {
    if (!_gameOver) return;

    if(_configProvider.coins < battleBondSum + tieSum) {
      showLimit?.call("Not Enough Coins");
      return;
    }

    _gameOver = false;
    _chipModel = ChipModel.empty();
    _gameCard1 = null;
    _gameCard2 = null;
    notifyListeners();

    await Future.delayed(Duration(seconds: 1));

    deal();
  }
}
