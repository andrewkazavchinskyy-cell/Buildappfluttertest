import 'dart:math';

import 'package:battle_decks/models/models.dart';
import 'package:battle_decks/providers/providers.dart';
import 'package:battle_decks/utils/utils.dart';
import 'package:flutter/material.dart';

class MultiplayerGameProvider extends ChangeNotifier {
  MultiplayerGameProvider(
    this.showPlayer,
    this._configProvider,
    this.showMessage,
    this.showResults,
    this.showBattle,
  ) {
    init();
  }

  final ConfigProvider _configProvider;
  final void Function(String) showMessage;
  final void Function(PlayerModel) showPlayer;
  final void Function(PlayerModel) showResults;
  final void Function(
    List<PlayerModel> players,
    VoidCallback? onBattle,
    VoidCallback? onSurrender,
  )
  showBattle;
  final List<PlayerModel> _players = [];

  List<PlayerModel> get players => _players;

  final List<int> _activePlayers = [];

  ChipModel _chipModel = ChipModel.empty();

  ChipModel get chipModel => _chipModel;

  int _playerId = 0;

  bool _extraGame = false;

  bool get extraGame => _extraGame;

  bool _gameOver = false;

  bool get gameOver => _gameOver;

  PlayerModel get player => _players[_playerId];

  final List<BetAction> _betActions = [];

  List<BetAction> get betActions => _betActions;

  bool get canUndo => _betActions.isNotEmpty && !_gameOver;

  bool get canClear =>
      (player.chips.isNotEmpty || player.tieChips.isNotEmpty) && !_gameOver;

  bool get canDeal =>
      (player.chips.isNotEmpty || player.tieChips.isNotEmpty) && !_gameOver;

  void init() {
    _betActions.clear();
    _gameOver = false;
    _players.clear();
    _activePlayers.clear();
    _playerId = 0;
    for (int i = 0; i < _configProvider.playersNumber; i++) {
      _players.add(
        PlayerModel(
          id: i,
          name: "Player ${i + 1}",
          bank: _configProvider.coinsPerPerson,
          chips: [],
          tieChips: [],
        ),
      );
      _activePlayers.add(i);
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      showPlayer.call(player);
    });
  }

  void addBattleBond() {
    if (_gameOver) return;
    if (_chipModel.id == -1) return;
    final player = _players[_playerId];

    if (player.bank < player.tieChipsSum + player.chipsSum + _chipModel.value) {
      showMessage.call("Not enough coins");
      return;
    }

    player.chips.add(_chipModel);
    _betActions.add(BetAction.battleBond);
    notifyListeners();
  }

  void addTie() {
    if (_gameOver) return;
    if (_chipModel.id == -1) return;
    final player = _players[_playerId];

    if (player.bank < player.tieChipsSum + player.chipsSum + _chipModel.value) {
      showMessage.call("Not enough coins");
      return;
    }

    player.tieChips.add(_chipModel);
    _betActions.add(BetAction.tie);
    notifyListeners();
  }

  void selectChip(ChipModel chip) {
    _chipModel = chip;
    notifyListeners();
  }

  void onNewGame() {
    _extraGame = false;
    _gameOver = false;
    _betActions.clear();
    _playerId = 0;
    _chipModel = ChipModel.empty();
    _activePlayers.clear();

    for (var player in _players) {
      player.bank = _configProvider.coinsPerPerson;
      player.chips.clear();
      player.tieChips.clear();
      player.gameCard = null;
      _activePlayers.add(player.id);
    }

    notifyListeners();

    showPlayer.call(player);
  }

  void undo() {
    if (_betActions.isEmpty || _gameOver) return;
    final action = _betActions.last;

    if (action == BetAction.battleBond) {
      _players[_playerId].chips.removeLast();
    } else {
      _players[_playerId].tieChips.removeLast();
    }

    _betActions.removeLast();
    notifyListeners();
  }

  void clear() {
    if (_gameOver) return;
    _betActions.clear();
    _players[_playerId].chips.clear();
    _players[_playerId].tieChips.clear();
    notifyListeners();
  }

  void deal() async {
    if (_gameOver) return;

    if (!_extraGame) {
      _players[_playerId].bank -=
          (_players[_playerId].chipsSum + _players[_playerId].tieChipsSum);
      notifyListeners();
    }

    if (_playerId == _players.length - 1) {
      _gameOver = true;
      for (PlayerModel player in _players) {
        final list = [];

        int x = Random().nextInt(gameCards.length);

        while (list.contains(x)) {
          x = Random().nextInt(gameCards.length);
        }

        list.add(x);
        player.gameCard = gameCards[x];
      }

      await Future.delayed(Duration(seconds: 1));

      int maxRank = _players.first.gameCard!.rank;

      for (PlayerModel player in _players) {
        if (!_activePlayers.contains(player.id)) continue;
        if (player.gameCard!.rank > maxRank) {
          maxRank = player.gameCard!.rank;
        }
      }

      final list = <PlayerModel>[];
      for (var player in _players) {
        if (!_activePlayers.contains(player.id)) continue;
        if (maxRank == player.gameCard!.rank) {
          list.add(player);
        } else {
          _activePlayers.remove(player.id);
        }
      }

      if (list.length == 1) {
        showResults.call(list[0]);
        final allPlayersSum = _players.fold(0, (a, b) => a + b.chipsSum);
        list[0].bank += allPlayersSum;
      } else {
        showBattle.call(list, _onBattle, _onSurrender);
        for (var player in list) {
          player.bank += (_players[_playerId].tieChipsSum);
        }
      }

      notifyListeners();
      return;
    }

    _playerId++;
    _betActions.clear();
    notifyListeners();

    showPlayer.call(player);
  }

  void _onBattle() {
    _extraGame = true;
    for (var player in _players) {
      if (_activePlayers.contains(player.id)) {
        final minSum = player.chipsSum ~/ _activePlayers.length;
        if (player.bank < minSum) {
          showMessage.call(
            "${player.name} doesn’t have money to\naccept Battle",
          );
          return;
        } else {
          player.bank -= minSum;
          player.chips.add(
            ChipModel(id: -1, value: minSum, asset: '', selectedAsset: ''),
          );
        }
      }
    }

    _gameOver = false;
    deal();
  }

  void _onSurrender() {
    _players[_playerId].bank += (_players[_playerId].tieChipsSum * 10);
    notifyListeners();
  }
}
