import 'package:battle_decks/models/models.dart';

final List<ChipModel> chipsList = [
  ChipModel(
    id: 0,
    value: 10,
    asset: 'assets/png/chip10.png',
    selectedAsset: 'assets/png/chip10_selected.png',
  ),
  ChipModel(
    id: 1,
    value: 25,
    asset: 'assets/png/chip25.png',
    selectedAsset: 'assets/png/chip25_selected.png',
  ),
  ChipModel(
    id: 2,
    value: 50,
    asset: 'assets/png/chip50.png',
    selectedAsset: 'assets/png/chip50_selected.png',
  ),
  ChipModel(
    id: 3,
    value: 100,
    asset: 'assets/png/chip100.png',
    selectedAsset: 'assets/png/chip100_selected.png',
  ),
  ChipModel(
    id: 4,
    value: 250,
    asset: 'assets/png/chip250.png',
    selectedAsset: 'assets/png/chip250_selected.png',
  ),
  ChipModel(
    id: 5,
    value: 500,
    asset: 'assets/png/chip500.png',
    selectedAsset: 'assets/png/chip500_selected.png',
  ),
];
