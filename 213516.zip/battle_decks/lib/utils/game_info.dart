import 'package:battle_decks/models/models.dart';

final List<Paragraph> gameInfo = [
  Paragraph(
    title: "Place Your Battle Bond ",
    body: "Select your main stake to start the duel.",
  ),
  Paragraph(
    title: "Optional Tie Stake",
    body:
        "You can also place a wager on a Tie for higher rewards. This kind of bet can be made only after Battle Bond .",
  ),
  Paragraph(
    title: "Reveal the Cards ",
    body: "Both you and your opponent reveal your cards.",
  ),
  Paragraph(
    title: "Win, Lose, or Tie:",
    body: """If your card is higher — you win your Battle Bond.
If it's lower — you lose your Battle Bond and the Tie stake.
If it's a Tie — you win 10x your Tie stake and can: 
Collect Half of Battle Bond — take 50% of your main stake. 
Go to Battle — double your stake and enter a new duel.""",
  ),
  Paragraph(
    title: "Battle Round (if chosen):",
    body:
        "Your main stake is automatically doubled.\nNew cards are revealed to determine the final winner.",
  ),
  Paragraph(title: "Repeat & Conquer!", body: ""),
];
