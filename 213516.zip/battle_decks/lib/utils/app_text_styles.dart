import 'package:battle_decks/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppTextStyles {
  static const _grenze = "Grenze";
  static const _grenzeGotisch = "GrenzeGotisch";

  static final TextStyle headerXLBold = TextStyle(
    fontFamily: _grenzeGotisch,
    fontWeight: FontWeight.w700,
    fontSize: 48.r,
    height: 1.2,
    color: Colors.white,
  );

  static final TextStyle headerLBold = TextStyle(
    fontFamily: _grenzeGotisch,
    fontWeight: FontWeight.w700,
    fontSize: 32.r,
    height: 1.2,
    color: AppColors.otherOther1,
  );

  static final TextStyle headerMBold = TextStyle(
    fontFamily: _grenzeGotisch,
    fontWeight: FontWeight.w700,
    fontSize: 24.r,
    height: 1.2,
    color: AppColors.textPrimary,
  );

  static final TextStyle headerMSecondary = TextStyle(
    fontFamily: _grenze,
    fontWeight: FontWeight.w700,
    fontSize: 24.r,
    height: 1.2,
    color: AppColors.textPrimary,
  );

  static final TextStyle headerSSecondary = TextStyle(
    fontFamily: _grenze,
    fontWeight: FontWeight.w700,
    fontSize: 20.r,
    height: 1.2,
    color: AppColors.textPrimary,
  );

  static final TextStyle headerSPrimaryBold = TextStyle(
    fontFamily: _grenzeGotisch,
    fontWeight: FontWeight.w700,
    fontSize: 20.r,
    height: 1.2,
    color: AppColors.accentPrimary,
  );

  static final TextStyle bodyPrimary = TextStyle(
    fontFamily: _grenze,
    fontWeight: FontWeight.w400,
    fontSize: 16.r,
    height: 1.2,
    color: AppColors.textSecondary,
  );

  static final TextStyle bodySemibold = TextStyle(
    fontFamily: _grenze,
    fontWeight: FontWeight.w600,
    height: 1.2,
    color: Colors.white,
  );

  static final TextStyle caption = TextStyle(
    fontFamily: _grenze,
    fontWeight: FontWeight.w600,
    fontSize: 12.r,
    height: 1.2,
    color: AppColors.systemError,
  );
}
