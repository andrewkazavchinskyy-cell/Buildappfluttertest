import 'package:flutter/material.dart';

class AppColors {
  static const Color backgroundPrimary = Color(0xFF1E1B2C);
  static const Color backgroundSecondary = Color(0xFF1E1B2C);
  static const Color accentPrimary = Color(0xFFBA0609);
  static const Color layersLayer1 = Color(0xFF272338);
  static const Color layersLayer2 = Color(0xFF463E67);
  static const Color layersLayer3 = Color(0xFFBA062A);
  static const Color layersLayer4 = Color(0xFFC81317);
  static const Color textPrimary = Color(0xFFFFFBFB);
  static const Color textSecondary = Color(0xFFADAABA);
  static const Color systemSuccess = Color(0xFF20B24B);
  static const Color systemError = Color(0xFFFF135E);
  static const Color strokeStroke1 = Color(0xFF665C8B);
  static const Color strokeStroke2 = Color(0xFFDD2D2F);
  static const Color strokeStroke3 = Color(0xFFDD2D4A);
  static const Color otherOther1 = Color(0xFFFFB703);
  static const Color otherOther2 = Color(0xFF784BFD);
}